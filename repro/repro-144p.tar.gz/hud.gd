extends Control
## HUD 144PRecord interaktif (simulasi tampilan; logika game asli tidak ikut).

var ammo := 30
var reserve := 90
var health := 100.0
var leaning := 0
var joy_active := false
var joy_center := Vector2.ZERO
var scoped := false

@onready var ammo_label: Label = $AmmoBox/Ammo
@onready var health_bar: ProgressBar = $TopLeft/Info/HealthRow/Health
@onready var hitmarker: Control = $Crosshair/Hitmarker
@onready var knob: TextureRect = $Joystick/Knob
@onready var joy: Control = $Joystick
@onready var kills: VBoxContainer = $TopRight/Kills
@onready var fire_sfx: AudioStreamPlayer = $FireSfx
@onready var dmg: TextureRect = $Crosshair/DamageDir

func _ready():
	_update_ammo()
	health_bar.value = health

func _update_ammo():
	ammo_label.text = "%d / %d" % [ammo, reserve]

func _blink_hitmarker():
	hitmarker.visible = true
	var tw = create_tween()
	tw.tween_interval(0.18)
	tw.tween_callback(func(): hitmarker.visible = false)

func _on_fire_pressed():
	if ammo <= 0:
		_on_reload_pressed()
		return
	ammo -= 1
	_update_ammo()
	fire_sfx.play()
	_blink_hitmarker()
	# recoil ringan di crosshair
	var tw = create_tween()
	tw.tween_property($Crosshair, "scale", Vector2(1.25, 1.25), 0.05)
	tw.tween_property($Crosshair, "scale", Vector2.ONE, 0.08)

func _on_reload_pressed():
	if reserve <= 0 or ammo >= 30:
		return
	var need = mini(30 - ammo, reserve)
	ammo += need
	reserve -= need
	_update_ammo()
	if $ReloadSfx.stream:
		$ReloadSfx.play()

func _on_jump_pressed():
	_hop($Jump)

func _on_crouch_pressed():
	_hop($Crouch)

func _on_grenade_pressed():
	_hop($Grenade)
	_add_kill("Kamu", "Musuh-3", "granat")

func _on_knife_pressed():
	_hop($Knife)

func _on_scope_pressed():
	scoped = not scoped
	$Scope.modulate = Color(0.5, 1, 0.5) if scoped else Color.WHITE

func _on_leanl_pressed():
	leaning = -1 if leaning != -1 else 0
	$LeanL.modulate = Color(0.5, 1, 0.5) if leaning == -1 else Color.WHITE
	$LeanR.modulate = Color.WHITE

func _on_leanr_pressed():
	leaning = 1 if leaning != 1 else 0
	$LeanR.modulate = Color(0.5, 1, 0.5) if leaning == 1 else Color.WHITE
	$LeanL.modulate = Color.WHITE

func _on_chat_pressed():
	_add_kill("Tim-A", "Tim-B", "chat")

func _hop(btn):
	var tw = create_tween()
	tw.tween_property(btn, "scale", Vector2(0.85, 0.85), 0.06)
	tw.tween_property(btn, "scale", Vector2.ONE, 0.08)

func _add_kill(a, b, dengan):
	var l = Label.new()
	l.text = "%s ☠ %s (%s)" % [a, b, dengan]
	l.add_theme_font_size_override("font_size", 20)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	kills.add_child(l)
	while kills.get_child_count() > 4:
		kills.get_child(0).queue_free()

# joystick: drag di area base
func _on_joystick_gui_input(event):
	if event is InputEventScreenTouch:
		joy_active = event.pressed
		if joy_active:
			joy_center = joy.size * 0.5
		else:
			knob.position = joy.size * 0.5 - knob.size * 0.5
	elif event is InputEventScreenDrag and joy_active:
		_move_knob(event.relative)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		joy_active = event.pressed
		if not joy_active:
			knob.position = joy.size * 0.5 - knob.size * 0.5
	elif event is InputEventMouseMotion and joy_active and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_move_knob(event.relative)

func _move_knob(rel):
	var c = joy.size * 0.5
	var k = knob.position + knob.size * 0.5 + rel - c
	if k.length() > 60.0:
		k = k.normalized() * 60.0
	knob.position = c + k - knob.size * 0.5

func _ready_joy():
	joy.gui_input.connect(_on_joystick_gui_input)
	$Fire.pressed.connect(_on_fire_pressed)
	$Reload.pressed.connect(_on_reload_pressed)
	$Jump.pressed.connect(_on_jump_pressed)
	$Crouch.pressed.connect(_on_crouch_pressed)
	$Grenade.pressed.connect(_on_grenade_pressed)
	$Knife.pressed.connect(_on_knife_pressed)
	$Scope.pressed.connect(_on_scope_pressed)
	$LeanL.pressed.connect(_on_leanl_pressed)
	$LeanR.pressed.connect(_on_leanr_pressed)
	$Chat.pressed.connect(_on_chat_pressed)

func _enter_tree():
	call_deferred("_ready_joy")

# demo hidup: health turun-naik + damage indicator
var _t := 0.0

func _process(delta):
	_t += delta
	if int(_t) % 12 == 0 and health > 20.0:
		health -= delta * 2.0
		health_bar.value = health
	elif int(_t) % 12 > 6 and health < 100.0:
		health += delta * 5.0
		health_bar.value = health
